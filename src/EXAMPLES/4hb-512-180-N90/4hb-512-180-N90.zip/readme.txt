-- CanDo submission --

Date and time: 2020-04-09 18:02:35
Name: danfudanfu
University/Institute/Company: Duke University
Email: daniel.fu@duke.edu
Filename: 4hb-512-180-N90.json
File type: square
Axial rise: 0.34
Helix diameter: 2.25
Crossover Spacing: 10.5
Axial stiffness: 1100
Bending stiffness: 230
Torsional stiffness: 460
Nick stiffness factor: 0.01
Model: coarse
Movie: no
Logged in: TRUE