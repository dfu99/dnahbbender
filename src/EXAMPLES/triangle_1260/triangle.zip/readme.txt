-- CanDo submission --

Date and time: 2018-11-21 12:18:36
Name: danfudanfu
University/Institute/Company: Duke University
Email: daniel.fu@duke.edu
Filename: triangle.json
File type: honeycomb
Axial rise: 0.34
Helix diameter: 2.25
Crossover Spacing: 10.5
Axial stiffness: 1100
Bending stiffness: 230
Torsional stiffness: 460
Nick stiffness factor: 0.01
Model: coarse
Movie: no
Logged in: TRUE